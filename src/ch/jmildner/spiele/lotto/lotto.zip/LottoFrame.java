
package ch.jmildner.spiele.lotto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LottoFrame
        extends JFrame
{
    private static final long serialVersionUID = 1L;


    public LottoFrame()
    {
        super("Lotto");
        Container cont = getContentPane();
        cont.add(new LottoPanel(this));
        setLocation(200, 100);
        packAndShow();
        addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                System.exit(0);
            }
        });
    }


    public void packAndShow()
    {
        pack();
        setVisible(true);
    }


    public static void main(String[] args)
    {
        new LottoFrame();
    }
}
