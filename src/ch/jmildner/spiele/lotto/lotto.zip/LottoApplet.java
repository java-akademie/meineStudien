
package ch.jmildner.spiele.lotto;

import javax.swing.*;
import java.awt.*;

public class LottoApplet
        extends JApplet
{
    private static final long serialVersionUID = 1L;


    public void init()
    {
        Container cont = getContentPane();
        cont.add(new LottoPanel());
    }
}
